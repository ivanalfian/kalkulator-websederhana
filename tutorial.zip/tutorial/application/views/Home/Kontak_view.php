<div class="Konten">

<!–Map Jalan Romo–>
<iframe src="https://goo.gl/maps/gzCTqT37dQqkVVeK7" width="1000" height="300" frameborder="0″"style="border:0"></iframe>
<hr>

<h1>myhome</h1>
<p>Home Office:<br>
tamanan wetan banguntapan,bantul<br>
tamanan wetan<br>
Phone: 085795329426<br>
Email: <a href="ivankurniawan230203@gmail.com">contact@ivankurniawan230203@gmail.com</a>, ivankurniawan230203@gmail.com<br>
</div>