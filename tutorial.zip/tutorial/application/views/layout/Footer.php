<div class="clearfix"></div>
<footer><a href="https://www.instagram.com/ivan__alfian/" target="_blank">@ivan__alfian</a> | &copy;by ivan alfian - 2020</footer></div>
</body>
</html>