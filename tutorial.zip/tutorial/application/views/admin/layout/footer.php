<div class="clearfix"></div>
    <footer>Web Design by ivan alfian - &copy; by ivan alfian </footer>    
</div>
</body>
</html>