<?php
require_once('head.php');
require_once('header.php');
require_once('menu.php');
require_once('konten.php');
require_once('footer.php');